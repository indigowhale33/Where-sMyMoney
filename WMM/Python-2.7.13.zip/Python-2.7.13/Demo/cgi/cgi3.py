#!/usr/bin/env python

"""CGI test 3 (persistent data)."""

import cgitb; cgitb.enable()

from wiki import main

if __name__ == "__main__":
    main()
